var deathSound = new Audio("assets/death.wav");
var explodeSound = new Audio("assets/explode.wav");
var fireSound = new Audio("assets/fire.wav");
var towerplaceSound = new Audio("assets/towerplace.wav");
var towersellSound = new Audio("assets/towersell.wav");
